# -*- coding: utf-8 -*-
"""Digital Forensics Date and Time (dfDateTime).

dfDateTime, or Digital Forensics date and time, provides date and time
objects to preserve accuracy and precision.
"""

__version__ = '20190517'
